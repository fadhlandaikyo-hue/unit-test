ALTER TABLE `project_progress`
  MODIFY `progress` DOUBLE NOT NULL DEFAULT 0;
