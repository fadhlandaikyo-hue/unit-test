import {prismaClient} from "../application/database.js";

export const getProgress = async (req, res, next) => {
    try {
        const projectId = Number(req.params.id)
        if (!Number.isInteger(projectId) || projectId <= 0) {
            return res.status(400).json({ errors: "project id is invalid" })
        }

        const rows = await prismaClient.$queryRaw`
            SELECT progress
            FROM project_progress
            WHERE project_id = ${projectId}
            LIMIT 1
        `
        res.json({ data: { progress: Number(rows[0]?.progress ?? 0) } })
    } catch (e) {
        next(e)
    }
}

export const updateProgress = async (req, res, next) => {
    try {
        const projectId = Number(req.params.id)
        if (!Number.isInteger(projectId) || projectId <= 0) {
            return res.status(400).json({ errors: "project id is invalid" })
        }

        const progress = Number(req.body.progress)
        if (!Number.isFinite(progress) || progress < 0 || progress > 100) {
            return res.status(400).json({ errors: "progress must be number 0..100" })
        }
        const roundedProgress = Math.round(progress * 10) / 10

        await prismaClient.$executeRaw`
            INSERT INTO project_progress (project_id, progress, updated_at)
            VALUES (${projectId}, ${roundedProgress}, CURRENT_TIMESTAMP(3))
            ON DUPLICATE KEY UPDATE
                progress = VALUES(progress),
                updated_at = CURRENT_TIMESTAMP(3)
        `

        res.json({ data: { project_id: projectId, progress: roundedProgress } })
    } catch (e) {
        next(e)
    }
}
