-- AlterTable
ALTER TABLE `users` ADD COLUMN `email` VARCHAR(200) NULL,
    ADD COLUMN `role` VARCHAR(100) NULL;
